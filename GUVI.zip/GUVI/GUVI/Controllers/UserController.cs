﻿using GUVI.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GUVI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly UserContext _context; 
        public UserController(UserContext context) { 
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> GetUserDetails() 
        { 
            return await _context.User.ToListAsync();
        }
        private int GetUserId(int id)
        {
            var userDetails = _context.User.SingleOrDefault(x => x.Id == id);
            _context.Entry(userDetails).State = EntityState.Detached;
            return userDetails.Id;
        }


        [HttpGet]
        [Route("getUser")]
        public ActionResult<User> GetUser(int id)
        {
            var details = _context.User.Where(x => x.Id == id).Select(x => new { x.Age, x.DOB, x.Contact, x.Address }).FirstOrDefault();
            return Ok(details);
        }

        [HttpPost]
        [Route("registerUser")]
        public async Task<ActionResult<User>> RegisterUser(User user)
        {
            var userPassword = getEncryptedCode(user.Pswd);
            user.Pswd = userPassword;
            _context.User.Add(user);
            await _context.SaveChangesAsync();
            return Ok(CreatedAtAction(nameof(GetUserDetails),new { id = user.Id},user));
        }

        [HttpPut]
        [Route("updateUser")]
        public async Task<ActionResult<User>> UpdateUser( int id, User user)
        {
            if (id != user.Id) 
            { 
                return BadRequest();
            }
            user.Id = GetUserId(id);
            _context.Entry(user).Property(x => x.DOB).IsModified = false;
            _context.User.Update(user);
            _context.SaveChanges(); 
            return NoContent();
        }

        public static string getEncryptedCode(string inputString)
        {
            byte[] tmpSource;
            byte[] tmpHash;
            int index = 0;
            int hashLength = 0;
            tmpSource = System.Text.ASCIIEncoding.ASCII.GetBytes(inputString);
            tmpHash = new System.Security.Cryptography.SHA512Managed().ComputeHash(tmpSource);
            hashLength = tmpHash.Length;
            System.Text.StringBuilder outputString = new System.Text.StringBuilder(hashLength);
            for (index = 0;
                index < hashLength; index++)
            {
                outputString.Append(tmpHash[index].ToString("X2"));
            }
            return outputString.ToString();
        }
    }
}