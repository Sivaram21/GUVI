﻿using GUVI.Model;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GUVI.Controllers
{
    public class LoginController : ControllerBase
    {
        private readonly UserContext _context;
        public LoginController(UserContext context)
        {
            _context = context;
        }

        [Route("verifyLogin")]
        [HttpGet]
        public ActionResult VerifyLogin(string userName, string password)
        { 
            string userPassword = _context.User.Where(e => (e.UserName == userName)).Select(e => e.Pswd).FirstOrDefault(); 
            if (userPassword != null)
            {
                password = getEncryptedCode(password);
                if (password == userPassword)
                {
                    var data = _context.User.Where(e => (e.UserName == userName)).Select(e => e.Id).FirstOrDefault();
                    return Ok(data);
                }
            } 
            return Ok("Invalid Login");
        }

            public static string getEncryptedCode(string inputString)
        { 
            byte[] tmpSource; 
            byte[] tmpHash; 
            int index = 0; 
            int hashLength = 0; 
            tmpSource = System.Text.ASCIIEncoding.ASCII.GetBytes(inputString); 
            tmpHash = new System.Security.Cryptography.SHA512Managed().ComputeHash(tmpSource); 
            hashLength = tmpHash.Length;
            System.Text.StringBuilder outputString = new System.Text.StringBuilder(hashLength);
            for (index = 0; 
                index < hashLength; index++) {
                outputString.Append(tmpHash[index].ToString("X2")); 
            } 
            return outputString.ToString();
        }
    }
}

